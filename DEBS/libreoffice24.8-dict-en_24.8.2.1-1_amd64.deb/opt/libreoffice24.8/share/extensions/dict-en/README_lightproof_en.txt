English sentence checker for LibreOffice
see git://anongit.freedesktop.org/libreoffice/lightproof
2011-2012 (c) László Németh, license: MPL 1.1 / GPLv3+ / LGPLv3+
